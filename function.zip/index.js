import fetch from "node-fetch"


exports.handler = async function() {

    const payload = {
        "method": "POST",
        "body": "wathever"
    }

    const res = await fetch("https://reqres.in/api/users?page=2", payload)

    await res.json();
    console.log(res);

    return res

}
